export default function Sobre(){
    return(
        <section className="sobre">
            <h2>Sobre</h2>
            <p>Seja bem-vindo à minha página de cachorrinhos! Aqui iremos falar sobre cachorros.
            </p>
        </section>
    )
}