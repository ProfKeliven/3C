export default function Banner(){
    return(
        <section className="banner">
            <img src="./banner.jpg"/>
        </section>
    )
}