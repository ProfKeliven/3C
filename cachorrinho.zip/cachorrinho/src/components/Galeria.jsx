import Img from '../../public/dog.jpg'

export default function Galeria() {
    return (
        <>
            <section className="galeria" id='i1'>
                <figure>
                    <img src={Img}></img>
                </figure>
                <figure>
                    <img src={Img}></img>
                </figure>
                <figure>
                    <img src={Img}></img>
                </figure>
            </section>
            <section className="galeria" id='i2'>
                <figure>
                    <img src={Img}></img>
                </figure>
                <figure>
                    <img src={Img}></img>
                </figure>
                <figure>
                    <img src={Img}></img>
                </figure>
            </section>
            <section className="galeria" id='i3'>
                <figure>
                    <img src={Img}></img>
                </figure>
                <figure>
                    <img src={Img}></img>
                </figure>
                <figure>
                    <img src={Img}></img>
                </figure>
            </section>
        </>
    )
}