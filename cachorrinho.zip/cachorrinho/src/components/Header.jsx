function Header(){
    return(
      <header>
        <h1>página de cachorrinho</h1>
      </header>
    )
}

export default Header